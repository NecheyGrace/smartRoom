/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "liquidcrystali2c.h"
#include "stm32f0xx_hal.h"
#include "stm32f0xx_hal_gpio.h"
#include "stm32f0xx_hal_uart.h"
#include <stdint.h>
#include <stdio.h>
#include <bluetooth.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int8_t Button_Debounce(); // for buttonce debouncing 


int8_t Object_Present(); // ultrasonics sensor 

void delay_us(uint32_t us);   // delayed code written 

int button_pressed = 0; // when the button is being pressed. 


int _write(int file, char *ptr, int len);

uint32_t last_lcd_off_time = 0;




 uint8_t system_on = 0;       // Set to 1 after button press, cleared to 0 by second press
uint8_t lcd_on = 0;          // 1 if LCD currently ON
uint32_t lcd_timer = 0;      // for LCD ON timing
 uint8_t our_bluetooth;  


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
 HD44780_Clear();

   

  /* USER CODE END 2 */
  HAL_UART_Receive_IT(&huart1, &our_bluetooth, 1); // for bluetooth
  
  
  //BT_SendString("saheed"); 



  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  // while (1)


  //// Testing ultrasonic sensor/////



//   {
//     if (Object_Present()) {
//         // TURN LED ON when object is detected
//         HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_SET);
//         // If you want a toggle/blink effect, use this instead:
//         // HAL_GPIO_TogglePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin);
//         HAL_Delay(100); // LED will stay on or toggle briefly when detected
//     } else {
//         // TURN LED OFF when no object detected
//         HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_RESET);
//     }

//     HAL_Delay(100); // Wait a little before next check
// }


while (1)
{
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    
    if (button_pressed) //button pressing technique
    {
        button_pressed = 0;

        if (Button_Debounce())
        {
            if (system_on == 0)
            {
                // OFF → ON
                system_on = 1;
                lcd_on = 1;
                lcd_timer = HAL_GetTick();
                last_lcd_off_time =HAL_GetTick();

                HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_SET);

                HD44780_Init(2);
                HD44780_Clear();
                HD44780_SetCursor(5, 0);
                HD44780_PrintStr("MEETING");
                HD44780_SetCursor(3, 1);
                HD44780_PrintStr("IN PROGRESS");
                HD44780_Backlight();
            }
            else
            {
                // ON → OFF
                system_on = 0;
                lcd_on = 0;

                HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_RESET);
                HD44780_Clear();
                HD44780_NoBacklight();
            }
        }
    }

    


    if (system_on) // checking if system is on
    {
      
        if (lcd_on)
        {
            if ((HAL_GetTick() - lcd_timer) >= 10000)
            {
                lcd_on = 0;
                last_lcd_off_time = HAL_GetTick();
                HD44780_Clear();
                HD44780_NoBacklight();
                
            }
        }

        
        if (!lcd_on)
        {
            
            static uint32_t blink_timer = 0;
            if ((HAL_GetTick() - blink_timer) > 250)
            {
                blink_timer = HAL_GetTick();
                HAL_GPIO_TogglePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin);
            }

            
            if ((HAL_GetTick() - last_lcd_off_time) > 1000)
            {
                if (Object_Present())
                {
                    lcd_on = 1;
                    lcd_timer = HAL_GetTick();

                    
                    HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_SET);

                    HD44780_Init(2);
                    HD44780_Clear();
                    HD44780_SetCursor(5, 0);
                    HD44780_PrintStr("MEETING");
                    HD44780_SetCursor(3, 1);
                    HD44780_PrintStr("IN PROGRESS");
                    HD44780_Backlight();
                }
            }
        }
        else
        {
            // LCD is ON — LED steady ON
            HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_SET);
        }
    }

    HAL_Delay(10);

    /* USER CODE BEGIN 3 */
}
}


//     // 1. BUTTON TOGGLE: system ON/OFF
//     if (button_pressed) {
//         button_pressed = 0;

//         if (Button_Debounce()) {

//             if (system_on == 0) {
//                 // OFF → ON
//                 system_on = 1;

//                 HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_SET);

//                 lcd_on = 1;
//                 lcd_timer = HAL_GetTick();

//                 HD44780_Init(2);
//                 HD44780_Clear();
//                 HD44780_SetCursor(5, 0);
//                 HD44780_PrintStr("MEETING");
//                 HD44780_SetCursor(3, 1);
//                 HD44780_PrintStr("IN PROGRESS");
//                 HD44780_Backlight();

//             } else {
//                 // ON → OFF
//                 system_on = 0;

//                 HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_RESET);

//                 lcd_on = 0;

//                 HD44780_Clear();
//                 HD44780_NoBacklight();
//             }
//         }
//     }

//  
//     if (system_on && lcd_on) {
//         HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_SET);
//     }

//     
//     if (system_on && lcd_on) {
//         if ((HAL_GetTick() - lcd_timer) >= 10000) {

//             lcd_on = 0;
//             lcd_off_time = HAL_GetTick();  

//             HD44780_Clear();
//             HD44780_NoBacklight();
//         }
//     }

//   
//     if (system_on && !lcd_on) {

//         // LED BLINK
//         HAL_GPIO_TogglePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin);

//         // wait 2 seconds before allowing sensor retrigger
//         if ((HAL_GetTick() - lcd_off_time) > 2000) {

//             if (Object_Present()) {

//                 lcd_on = 1;
//                 lcd_timer = HAL_GetTick();

//                 HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_SET);

//                 HD44780_Init(2);
//                 HD44780_Clear();
//                 HD44780_SetCursor(5, 0);
//                 HD44780_PrintStr("MEETING");
//                 HD44780_SetCursor(3, 1);
//                 HD44780_PrintStr("IN PROGRESS");
//                 HD44780_Backlight();
//             }
//         }
//     }

//    
//     if (!system_on) {
//         lcd_on = 0;

//         HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_RESET);

//         HD44780_Clear();
//         HD44780_NoBacklight();
//     }

//     HAL_Delay(50);
// }


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00201D2B;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ONBOARD_LED_GPIO_Port, ONBOARD_LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, OUTBOARD_LED_Pin|FAN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : START_Pin STOP_Pin */
  GPIO_InitStruct.Pin = START_Pin|STOP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : ONBOARD_LED_Pin */
  GPIO_InitStruct.Pin = ONBOARD_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(ONBOARD_LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : OUTBOARD_LED_Pin FAN_Pin */
  GPIO_InitStruct.Pin = OUTBOARD_LED_Pin|FAN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : TRIG_Pin */
  GPIO_InitStruct.Pin = TRIG_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(TRIG_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ECHO_Pin */
  GPIO_InitStruct.Pin = ECHO_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ECHO_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  GPIO_InitStruct.Pin = BLUETOOTH_TX_Pin | BLUETOOTH_RX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF1_USART1;
  HAL_GPIO_Init(BLUETOOTH_TX_GPIO_Port, &GPIO_InitStruct);
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)       
{
  if (GPIO_Pin == START_Pin)     // the up button
  {
    button_pressed = 1;
  }
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if(huart -> Instance == USART1)
  {
    if(our_bluetooth =='1')
    {
      button_pressed =1;
    }
    HAL_UART_Receive_IT(huart,&our_bluetooth,1);
  }
}


void delay_us(uint32_t us)
{
    uint32_t start = HAL_GetTick(); // might be used later 
    // each tick = 1ms = 1000us
    // for short us delays we use a loop
    volatile uint32_t count = us * 6; // approximate at 48MHz
    while (count--);
}



int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart1, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}

int8_t Button_Debounce()
{
    int32_t static last = 0;
    int32_t now = HAL_GetTick(); // current time 

    if ((now - last) > 70)   // we are trying to debounce every 200ms since we dont have require hardware capacitor and resistor.
    {
        last = now;
        return 1;   // value becomes 1. 
    }

    return 0;  
}





int8_t Object_Present()
{
    // ===== Trigger pulse =====
    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);
    delay_us(2);

    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_SET);
    delay_us(10);

    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);

    // ===== Wait for ECHO to go HIGH (timeout 38ms) =====
    uint32_t start = HAL_GetTick();
    while (HAL_GPIO_ReadPin(ECHO_GPIO_Port, ECHO_Pin) == GPIO_PIN_RESET)
    {
        if ((HAL_GetTick() - start) > 38)
        {
            printf("Timeout — no echo\r\n");
            return 0;
        }
    }

    // ===== Measure how long ECHO stays HIGH =====
    uint32_t echo_start = HAL_GetTick();
    while (HAL_GPIO_ReadPin(ECHO_GPIO_Port, ECHO_Pin) == GPIO_PIN_SET)
    {
        if ((HAL_GetTick() - echo_start) > 38)
            break;
    }
    uint32_t echo_duration_ms = HAL_GetTick() - echo_start;

    // Convert ms to approximate cm
    // sound travels ~34cm per ms (340m/s)
    // distance = duration_ms * 17 (divide by 2 for round trip)
    float distance_cm = echo_duration_ms * 17.0f;

    printf("Duration: %lu ms, Distance: %.1f cm\r\n", echo_duration_ms, distance_cm);

    if (distance_cm > 2.0f && distance_cm < 100.0f)
        return 1;
    else
        return 0;
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
